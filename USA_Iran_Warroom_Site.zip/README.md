# USA Iran Warroom
قالب ساده و واکنش‌گرا برای سایت خبری.
فایل اصلی سایت: `index.html`
برای GitHub Pages کافی است فایل را در یک repository قرار دهید و Pages را فعال کنید.
